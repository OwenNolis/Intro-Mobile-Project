package com.mycompany.playtomictest

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
