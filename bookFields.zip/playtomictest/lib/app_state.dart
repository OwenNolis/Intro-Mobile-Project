import 'package:flutter/material.dart';
import '/backend/backend.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {}

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  Color _onPressChangeColor = Color(4283917164);
  Color get onPressChangeColor => _onPressChangeColor;
  set onPressChangeColor(Color _value) {
    _onPressChangeColor = _value;
  }

  String _timeSlot = '';
  String get timeSlot => _timeSlot;
  set timeSlot(String _value) {
    _timeSlot = _value;
  }

  bool _isButtonEnabled = false;
  bool get isButtonEnabled => _isButtonEnabled;
  set isButtonEnabled(bool _value) {
    _isButtonEnabled = _value;
  }

  List<String> _buttons = [];
  List<String> get buttons => _buttons;
  set buttons(List<String> _value) {
    _buttons = _value;
  }

  void addToButtons(String _value) {
    _buttons.add(_value);
  }

  void removeFromButtons(String _value) {
    _buttons.remove(_value);
  }

  void removeAtIndexFromButtons(int _index) {
    _buttons.removeAt(_index);
  }

  void updateButtonsAtIndex(
    int _index,
    String Function(String) updateFn,
  ) {
    _buttons[_index] = updateFn(_buttons[_index]);
  }

  void insertAtIndexInButtons(int _index, String _value) {
    _buttons.insert(_index, _value);
  }
}

Color? _colorFromIntValue(int? val) {
  if (val == null) {
    return null;
  }
  return Color(val);
}
