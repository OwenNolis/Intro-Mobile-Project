// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

// Set your action name, define your arguments and return parameter,
// and then add the boilerplate code using the green button on the right!
Future<List<String>> getBookedTimeslots(
    String courtName, String courtDate) async {
  /// MODIFY CODE ONLY BELOW THIS LINE
  try {
    // Query Firestore to fetch booked timeslots based on court name and date
    QuerySnapshot querySnapshot = await FirebaseFirestore.instance
        .collection('reservations')
        .where('courtName', isEqualTo: courtName)
        .where('courtDate', isEqualTo: courtDate)
        .get();

    // Extract booked timeslots from query snapshot
    List<String> bookedTimeslots = [];
    querySnapshot.docs.forEach((doc) {
      bookedTimeslots.add(doc['courtTime']);
    });

    return bookedTimeslots;
  } catch (e) {
    print('Error retrieving booked timeslots: $e');
    return []; // Return empty list if there's an error
  }

  /// MODIFY CODE ONLY ABOVE THIS LINE
}
