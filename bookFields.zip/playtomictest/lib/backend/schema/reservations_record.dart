import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ReservationsRecord extends FirestoreRecord {
  ReservationsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "userId" field.
  String? _userId;
  String get userId => _userId ?? '';
  bool hasUserId() => _userId != null;

  // "courtName" field.
  String? _courtName;
  String get courtName => _courtName ?? '';
  bool hasCourtName() => _courtName != null;

  // "courtDate" field.
  String? _courtDate;
  String get courtDate => _courtDate ?? '';
  bool hasCourtDate() => _courtDate != null;

  // "courtTime" field.
  String? _courtTime;
  String get courtTime => _courtTime ?? '';
  bool hasCourtTime() => _courtTime != null;

  void _initializeFields() {
    _userId = snapshotData['userId'] as String?;
    _courtName = snapshotData['courtName'] as String?;
    _courtDate = snapshotData['courtDate'] as String?;
    _courtTime = snapshotData['courtTime'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('reservations');

  static Stream<ReservationsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ReservationsRecord.fromSnapshot(s));

  static Future<ReservationsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ReservationsRecord.fromSnapshot(s));

  static ReservationsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ReservationsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ReservationsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ReservationsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ReservationsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ReservationsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createReservationsRecordData({
  String? userId,
  String? courtName,
  String? courtDate,
  String? courtTime,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'userId': userId,
      'courtName': courtName,
      'courtDate': courtDate,
      'courtTime': courtTime,
    }.withoutNulls,
  );

  return firestoreData;
}

class ReservationsRecordDocumentEquality
    implements Equality<ReservationsRecord> {
  const ReservationsRecordDocumentEquality();

  @override
  bool equals(ReservationsRecord? e1, ReservationsRecord? e2) {
    return e1?.userId == e2?.userId &&
        e1?.courtName == e2?.courtName &&
        e1?.courtDate == e2?.courtDate &&
        e1?.courtTime == e2?.courtTime;
  }

  @override
  int hash(ReservationsRecord? e) => const ListEquality()
      .hash([e?.userId, e?.courtName, e?.courtDate, e?.courtTime]);

  @override
  bool isValidKey(Object? o) => o is ReservationsRecord;
}
