import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyDmSQ2DXZoPuw5gT3zEI7FRpTmovOBBBF0",
            authDomain: "travel-app-95u9i9.firebaseapp.com",
            projectId: "travel-app-95u9i9",
            storageBucket: "travel-app-95u9i9.appspot.com",
            messagingSenderId: "945469977532",
            appId: "1:945469977532:web:3528d0fac169fc5f0eb1b9"));
  } else {
    await Firebase.initializeApp();
  }
}
