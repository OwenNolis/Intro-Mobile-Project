package com.mycompany.travelapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
