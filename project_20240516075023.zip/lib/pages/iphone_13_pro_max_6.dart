import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class Iphone13ProMax6 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        color: Color(0xFFFFFFFF),
        borderRadius: BorderRadius.circular(40),
      ),
      child: Container(
        padding: EdgeInsets.fromLTRB(0, 24.5, 0, 0),
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            SizedBox(
              width: 430.4,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    margin: EdgeInsets.fromLTRB(34, 0, 0, 14),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Container(
                            margin: EdgeInsets.fromLTRB(0, 3.5, 0, 0),
                            child: Container(
                              decoration: BoxDecoration(
                                image: DecorationImage(
                                  fit: BoxFit.cover,
                                  image: AssetImage(
                                    'assets/images/image_1.png',
                                  ),
                                ),
                              ),
                              child: Container(
                                height: 68,
                              ),
                            ),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 0, 13.5),
                          child: Text(
                            'velden reserveren + kalender available',
                            style: GoogleFonts.getFont(
                              'Inter',
                              fontWeight: FontWeight.w400,
                              fontSize: 24,
                              color: Color(0xFF000000),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(0, 0, 16.4, 69),
                    child: Text(
                      'Book your court',
                      style: GoogleFonts.getFont(
                        'Inter',
                        fontWeight: FontWeight.w400,
                        fontSize: 35,
                        color: Color(0xFF000000),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(0, 0, 266.2, 9),
                    child: Text(
                      'Field 1',
                      style: GoogleFonts.getFont(
                        'Inter',
                        fontWeight: FontWeight.w400,
                        fontSize: 24,
                        color: Color(0xFF000000),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(0, 0, 3.4, 344),
                    child: Container(
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          fit: BoxFit.cover,
                          image: AssetImage(
                            'assets/images/image_5.png',
                          ),
                        ),
                      ),
                      child: Container(
                        width: 335,
                        height: 164,
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(0, 0, 2.4, 0),
                    child: SizedBox(
                      width: 428,
                      height: 159,
                      child: SvgPicture.asset(
                        'assets/vectors/compon_4_x2.svg',
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              right: 64,
              bottom: 61,
              child: Container(
                decoration: BoxDecoration(
                  color: Color(0xFFF5F5F5),
                ),
                child: SizedBox(
                  width: 41,
                  height: 39,
                  child: Container(
                    padding: EdgeInsets.fromLTRB(5.1, 4.9, 5.1, 4.9),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          margin: EdgeInsets.fromLTRB(5.1, 0, 5.1, 0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(
                                width: 3.4,
                                height: 3.3,
                                child: SvgPicture.asset(
                                  'assets/vectors/path_173_x2.svg',
                                ),
                              ),
                              SizedBox(
                                width: 3.4,
                                height: 3.3,
                                child: SvgPicture.asset(
                                  'assets/vectors/path_171_x2.svg',
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 30.8,
                          height: 26,
                          child: SvgPicture.asset(
                            'assets/vectors/container_3_x2.svg',
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}