import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class Iphone13ProMax7 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        color: Color(0xFFFFFFFF),
        borderRadius: BorderRadius.circular(40),
      ),
      child: Stack(
        children: [
          Positioned(
            left: -26,
            top: 774,
            child: SizedBox(
              width: 428,
              height: 133,
              child: SvgPicture.asset(
                'assets/vectors/compon_3_x2.svg',
              ),
            ),
          ),
    Container(
            padding: EdgeInsets.fromLTRB(22, 19, 40, 23),
            child: Stack(
              clipBehavior: Clip.none,
              children: [
                SizedBox(
                  width: double.infinity,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 0, 35),
                        child: Align(
                          alignment: Alignment.topLeft,
                          child: SizedBox(
                            width: 262,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 0, 70, 66),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      image: DecorationImage(
                                        fit: BoxFit.cover,
                                        image: AssetImage(
                                          'assets/images/image_1.png',
                                        ),
                                      ),
                                    ),
                                    child: Container(
                                      width: 65,
                                      height: 68,
                                    ),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 34, 0, 0),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      image: DecorationImage(
                                        fit: BoxFit.cover,
                                        image: AssetImage(
                                          'assets/images/image_3.png',
                                        ),
                                      ),
                                    ),
                                    child: Container(
                                      width: 127,
                                      height: 100,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(17, 0, 0, 10),
                        child: Align(
                          alignment: Alignment.topCenter,
                          child: Text(
                            'View Profile',
                            style: GoogleFonts.getFont(
                              'Inder',
                              fontWeight: FontWeight.w400,
                              fontSize: 36,
                              color: Color(0xFF000000),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(17, 0, 0, 24),
                        child: Container(
                          decoration: BoxDecoration(
                            color: Color(0xFF000000),
                          ),
                          child: Container(
                            width: 349,
                            height: 1,
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(25, 0, 25, 12),
                        child: Align(
                          alignment: Alignment.topLeft,
                          child: Text(
                            'Email',
                            style: GoogleFonts.getFont(
                              'Inter',
                              fontWeight: FontWeight.w400,
                              fontSize: 26,
                              color: Color(0xFF6B6B6B),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(32, 0, 32, 25),
                        child: Align(
                          alignment: Alignment.topLeft,
                          child: Text(
                            's123456@ap.be',
                            style: GoogleFonts.getFont(
                              'Inter',
                              fontWeight: FontWeight.w400,
                              fontSize: 26,
                              decoration: TextDecoration.underline,
                              color: Color(0xFF6B6B6B),
                              decorationColor: Color(0xFF6B6B6B),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(25, 0, 25, 5),
                        child: Align(
                          alignment: Alignment.topLeft,
                          child: Text(
                            'Firstname',
                            style: GoogleFonts.getFont(
                              'Inter',
                              fontWeight: FontWeight.w400,
                              fontSize: 26,
                              color: Color(0xFF6B6B6B),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(25, 0, 25, 18),
                        child: Align(
                          alignment: Alignment.topLeft,
                          child: Container(
                            decoration: BoxDecoration(
                              border: Border.all(color: Color(0x36000000)),
                              borderRadius: BorderRadius.circular(10),
                              color: Color(0x61D9D9D9),
                            ),
                            child: Container(
                              padding: EdgeInsets.fromLTRB(10, 6, 10, 7),
                              child: Text(
                                'Test',
                                style: GoogleFonts.getFont(
                                  'Inter',
                                  fontWeight: FontWeight.w400,
                                  fontSize: 26,
                                  color: Color(0xFF6B6B6B),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(25, 0, 25, 15),
                        child: Align(
                          alignment: Alignment.topLeft,
                          child: Text(
                            'Lastname',
                            style: GoogleFonts.getFont(
                              'Inter',
                              fontWeight: FontWeight.w400,
                              fontSize: 26,
                              color: Color(0xFF6B6B6B),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(25, 0, 25, 18),
                        child: Align(
                          alignment: Alignment.topLeft,
                          child: Container(
                            decoration: BoxDecoration(
                              border: Border.all(color: Color(0x36000000)),
                              borderRadius: BorderRadius.circular(10),
                              color: Color(0x61D9D9D9),
                            ),
                            child: Container(
                              padding: EdgeInsets.fromLTRB(8, 6, 8, 7),
                              child: Text(
                                'Dummy',
                                style: GoogleFonts.getFont(
                                  'Inter',
                                  fontWeight: FontWeight.w400,
                                  fontSize: 26,
                                  color: Color(0xFF6B6B6B),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(25, 0, 25, 10),
                        child: Align(
                          alignment: Alignment.topLeft,
                          child: Text(
                            'Username',
                            style: GoogleFonts.getFont(
                              'Inter',
                              fontWeight: FontWeight.w400,
                              fontSize: 26,
                              color: Color(0xFF6B6B6B),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(25, 0, 25, 18),
                        child: Align(
                          alignment: Alignment.topLeft,
                          child: Container(
                            decoration: BoxDecoration(
                              border: Border.all(color: Color(0x36000000)),
                              borderRadius: BorderRadius.circular(10),
                              color: Color(0x61D9D9D9),
                            ),
                            child: Container(
                              padding: EdgeInsets.fromLTRB(10, 8, 10, 5),
                              child: Text(
                                'TestDummy1234',
                                style: GoogleFonts.getFont(
                                  'Inter',
                                  fontWeight: FontWeight.w400,
                                  fontSize: 26,
                                  color: Color(0xFF6B6B6B),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(25, 0, 25, 12),
                        child: Align(
                          alignment: Alignment.topLeft,
                          child: Text(
                            'Password',
                            style: GoogleFonts.getFont(
                              'Inter',
                              fontWeight: FontWeight.w400,
                              fontSize: 26,
                              color: Color(0xFF6B6B6B),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(25, 0, 25, 99),
                        child: Align(
                          alignment: Alignment.topLeft,
                          child: Container(
                            decoration: BoxDecoration(
                              border: Border.all(color: Color(0x36000000)),
                              borderRadius: BorderRadius.circular(10),
                              color: Color(0x61D9D9D9),
                            ),
                            child: Container(
                              padding: EdgeInsets.fromLTRB(7, 13, 7, 0),
                              child: Text(
                                '************',
                                style: GoogleFonts.getFont(
                                  'Inter',
                                  fontWeight: FontWeight.w400,
                                  fontSize: 26,
                                  color: Color(0xFF6B6B6B),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(13, 0, 13, 0),
                        child: Align(
                          alignment: Alignment.topRight,
                          child: SizedBox(
                            width: 44,
                            height: 41,
                            child: SvgPicture.asset(
                              'assets/vectors/calendar_x2.svg',
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Positioned(
                  left: 25,
                  top: 286,
                  child: Container(
                    decoration: BoxDecoration(
                      border: Border.all(color: Color(0x36000000)),
                      borderRadius: BorderRadius.circular(10),
                      color: Color(0x61D9D9D9),
                    ),
                    child: Container(
                      width: 300,
                      height: 44,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}