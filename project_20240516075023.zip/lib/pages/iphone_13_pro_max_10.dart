import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class Iphone13ProMax10 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        color: Color(0xFFFFFFFF),
        borderRadius: BorderRadius.circular(40),
      ),
      child: Stack(
        children: [
          Positioned(
            top: 774,
            child: SizedBox(
              width: 428,
              height: 133,
              child: SvgPicture.asset(
                'assets/vectors/compon_6_x2.svg',
              ),
            ),
          ),
    Container(
            padding: EdgeInsets.fromLTRB(22, 19, 0, 26),
            child: Stack(
              clipBehavior: Clip.none,
              children: [
                SizedBox(
                  width: 408.5,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 0, 26),
                        child: Align(
                          alignment: Alignment.topLeft,
                          child: SizedBox(
                            width: 262,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 0, 70, 66),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      image: DecorationImage(
                                        fit: BoxFit.cover,
                                        image: AssetImage(
                                          'assets/images/image_1.png',
                                        ),
                                      ),
                                    ),
                                    child: Container(
                                      width: 65,
                                      height: 68,
                                    ),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 34, 0, 0),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      image: DecorationImage(
                                        fit: BoxFit.cover,
                                        image: AssetImage(
                                          'assets/images/image_3.png',
                                        ),
                                      ),
                                    ),
                                    child: Container(
                                      width: 127,
                                      height: 100,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 26.5, 11),
                        child: Text(
                          'My Bookings',
                          style: GoogleFonts.getFont(
                            'Inder',
                            fontWeight: FontWeight.w400,
                            fontSize: 36,
                            color: Color(0xFF000000),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(26, 0, 33.5, 43),
                        child: Container(
                          decoration: BoxDecoration(
                            color: Color(0xFF000000),
                          ),
                          child: Container(
                            width: 349,
                            height: 1,
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(10, 0, 10, 29),
                        child: Align(
                          alignment: Alignment.topLeft,
                          child: SizedBox(
                            width: 299.4,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 0, 15.5, 0),
                                  child: SizedBox(
                                    width: 195.5,
                                    child: Text(
                                      'Upcoming',
                                      style: GoogleFonts.getFont(
                                        'Inter',
                                        fontWeight: FontWeight.w400,
                                        fontSize: 26,
                                        decoration: TextDecoration.underline,
                                        color: Color(0xFF6B6B6B),
                                        decorationColor: Color(0xFF6B6B6B),
                                      ),
                                    ),
                                  ),
                                ),
                                Text(
                                  'History',
                                  style: GoogleFonts.getFont(
                                    'Inter',
                                    fontWeight: FontWeight.w400,
                                    fontSize: 26,
                                    decoration: TextDecoration.underline,
                                    color: Color(0xFF0601FF),
                                    decorationColor: Color(0xFF0601FF),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(93.7, 0, 0, 21),
                        child: Text(
                          'Field 1',
                          style: GoogleFonts.getFont(
                            'Inter',
                            fontWeight: FontWeight.w400,
                            fontSize: 22,
                            color: Color(0xFF000000),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(150.3, 0, 0, 34),
                        child: Text(
                          'Red VS Blue',
                          style: GoogleFonts.getFont(
                            'Inter',
                            fontWeight: FontWeight.w400,
                            fontSize: 22,
                            color: Color(0xFF000000),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 0, 384),
                        child: Align(
                          alignment: Alignment.topRight,
                          child: Text(
                            '05/07 14:00-15:30',
                            style: GoogleFonts.getFont(
                              'Inter',
                              fontWeight: FontWeight.w400,
                              fontSize: 22,
                              color: Color(0xFF000000),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(253.5, 0, 0, 0),
                        child: SizedBox(
                          width: 44,
                          height: 41,
                          child: SvgPicture.asset(
                            'assets/vectors/calendar_5_x2.svg',
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Positioned(
                  right: 21,
                  top: 317,
                  child: Container(
                    decoration: BoxDecoration(
                      color: Color(0x61D9D9D9),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Container(
                      width: 160,
                      height: 156,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}