import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class Iphone13ProMax11 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        color: Color(0xFFFFFFFF),
        borderRadius: BorderRadius.circular(40),
      ),
      child: Stack(
        children: [
          Positioned(
            left: -195,
            top: 336,
            child: SizedBox(
              width: 643,
              height: 713,
              child: SvgPicture.asset(
                'assets/vectors/union_2_x2.svg',
              ),
            ),
          ),
    Container(
            padding: EdgeInsets.fromLTRB(2, 110, 0, 0),
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  fit: BoxFit.cover,
                  image: AssetImage(
                    'assets/images/image_1.png',
                  ),
                ),
              ),
              child: Container(
                width: 174,
                height: 306,
              ),
            ),
          ),
        ],
      ),
    );
  }
}