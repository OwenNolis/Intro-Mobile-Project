import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class Iphone13ProMax5 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        color: Color(0xFFFFFFFF),
        borderRadius: BorderRadius.circular(40),
      ),
      child: Stack(
        children: [
          Positioned(
            top: 774,
            child: SizedBox(
              width: 428,
              height: 133,
              child: SvgPicture.asset(
                'assets/vectors/compon_5_x2.svg',
              ),
            ),
          ),
    Container(
            padding: EdgeInsets.fromLTRB(22, 19, 22, 26),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 0, 29),
                  child: Align(
                    alignment: Alignment.topLeft,
                    child: Container(
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          fit: BoxFit.cover,
                          image: AssetImage(
                            'assets/images/image_1.png',
                          ),
                        ),
                      ),
                      child: Container(
                        width: 65,
                        height: 68,
                      ),
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(13, 0, 0, 17),
                  child: Container(
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        fit: BoxFit.cover,
                        image: AssetImage(
                          'assets/images/image_3.png',
                        ),
                      ),
                    ),
                    child: Container(
                      width: 127,
                      height: 100,
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(0, 0, 4, 74),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Color(0xFFF4EB1C),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Container(
                      padding: EdgeInsets.fromLTRB(5, 7, 4.8, 7),
                      child: Text(
                        'View Profile',
                        style: GoogleFonts.getFont(
                          'Inter',
                          fontWeight: FontWeight.w400,
                          fontSize: 24,
                          color: Color(0xFF000000),
                        ),
                      ),
                    ),
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(12, 0, 12, 480),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 14.5, 0),
                        child: SizedBox(
                          width: 307.5,
                          child: Text(
                            'My Bookings',
                            style: GoogleFonts.getFont(
                              'Inter',
                              fontWeight: FontWeight.w400,
                              fontSize: 24,
                              color: Color(0xFF000000),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(0, 14, 0, 13),
                        child: Container(
                          decoration: BoxDecoration(
                            color: Color(0xFF000000),
                          ),
                          child: Container(
                            width: 38,
                            height: 2,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.fromLTRB(278, 0, 0, 0),
                  child: SizedBox(
                    width: 44,
                    height: 41,
                    child: SvgPicture.asset(
                      'assets/vectors/calendar_2_x2.svg',
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}