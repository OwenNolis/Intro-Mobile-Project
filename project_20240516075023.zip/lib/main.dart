import 'package:flutter/material.dart';

import 'package:flutter_app/pages/dropdown_box.dart';
import 'package:flutter_app/pages/iphone_13_pro_max_10.dart';
import 'package:flutter_app/pages/iphone_13_pro_max_11.dart';
import 'package:flutter_app/pages/iphone_13_pro_max_2.dart';
import 'package:flutter_app/pages/iphone_13_pro_max_21.dart';
import 'package:flutter_app/pages/iphone_13_pro_max_3.dart';
import 'package:flutter_app/pages/iphone_13_pro_max_4.dart';
import 'package:flutter_app/pages/iphone_13_pro_max_5.dart';
import 'package:flutter_app/pages/iphone_13_pro_max_6.dart';
import 'package:flutter_app/pages/iphone_13_pro_max_7.dart';
import 'package:flutter_app/pages/iphone_13_pro_max_8.dart';
import 'package:flutter_app/pages/iphone_13_pro_max_9.dart';


void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter App',
      home: Scaffold(

        body: DropdownBox(),
        // body: Iphone13ProMax10(),
        // body: Iphone13ProMax11(),
        // body: Iphone13ProMax2(),
        // body: Iphone13ProMax21(),
        // body: Iphone13ProMax3(),
        // body: Iphone13ProMax4(),
        // body: Iphone13ProMax5(),
        // body: Iphone13ProMax6(),
        // body: Iphone13ProMax7(),
        // body: Iphone13ProMax8(),
        // body: Iphone13ProMax9(),

      ),
    );
  }
}
