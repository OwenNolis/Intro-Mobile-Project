const admin = require("firebase-admin/app");
admin.initializeApp();

const function1 = require("./function1.js");
exports.function1 = function1.function1;
