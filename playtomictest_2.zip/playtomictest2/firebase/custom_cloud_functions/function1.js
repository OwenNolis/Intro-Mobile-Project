const functions = require("firebase-functions");
const admin = require("firebase-admin");

admin.initializeApp();

exports.function1 = functions.https.onRequest(async (req, res) => {
  try {
    const currentUserID = req.query.userID; // Get the user ID from the request query parameters
    if (!currentUserID) {
      throw new Error("User ID is missing.");
    }

    // Query Firestore to get reservations associated with the user's ID
    const querySnapshot = await admin
      .firestore()
      .collection("reservations")
      .where("userID", "==", currentUserID)
      .get();

    // Extract booking details from query snapshot
    const bookings = [];
    querySnapshot.forEach((doc) => {
      const booking = {
        id: doc.id,
        courtDate: doc.data().courtDate,
        courtTime: doc.data().courtTime,
        courtName: doc.data().courtName,
        // Add more fields as needed
      };
      bookings.push(booking);
    });

    // Return the booking details as JSON response
    res.status(200).json(bookings);
  } catch (error) {
    console.error("Error getting bookings:", error);
    res.status(500).send("Error getting bookings.");
  }
});
