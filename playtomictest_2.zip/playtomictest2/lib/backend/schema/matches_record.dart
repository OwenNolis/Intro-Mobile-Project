import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class MatchesRecord extends FirestoreRecord {
  MatchesRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "courtName" field.
  String? _courtName;
  String get courtName => _courtName ?? '';
  bool hasCourtName() => _courtName != null;

  // "courtDate" field.
  String? _courtDate;
  String get courtDate => _courtDate ?? '';
  bool hasCourtDate() => _courtDate != null;

  // "courtTime" field.
  String? _courtTime;
  String get courtTime => _courtTime ?? '';
  bool hasCourtTime() => _courtTime != null;

  // "userId" field.
  String? _userId;
  String get userId => _userId ?? '';
  bool hasUserId() => _userId != null;

  // "participantsJoined" field.
  int? _participantsJoined;
  int get participantsJoined => _participantsJoined ?? 0;
  bool hasParticipantsJoined() => _participantsJoined != null;

  // "maxParticipants" field.
  int? _maxParticipants;
  int get maxParticipants => _maxParticipants ?? 0;
  bool hasMaxParticipants() => _maxParticipants != null;

  // "participants" field.
  String? _participants;
  String get participants => _participants ?? '';
  bool hasParticipants() => _participants != null;

  // "participant1" field.
  String? _participant1;
  String get participant1 => _participant1 ?? '';
  bool hasParticipant1() => _participant1 != null;

  // "participant2" field.
  String? _participant2;
  String get participant2 => _participant2 ?? '';
  bool hasParticipant2() => _participant2 != null;

  // "participant3" field.
  String? _participant3;
  String get participant3 => _participant3 ?? '';
  bool hasParticipant3() => _participant3 != null;

  // "participant4" field.
  String? _participant4;
  String get participant4 => _participant4 ?? '';
  bool hasParticipant4() => _participant4 != null;

  void _initializeFields() {
    _courtName = snapshotData['courtName'] as String?;
    _courtDate = snapshotData['courtDate'] as String?;
    _courtTime = snapshotData['courtTime'] as String?;
    _userId = snapshotData['userId'] as String?;
    _participantsJoined = castToType<int>(snapshotData['participantsJoined']);
    _maxParticipants = castToType<int>(snapshotData['maxParticipants']);
    _participants = snapshotData['participants'] as String?;
    _participant1 = snapshotData['participant1'] as String?;
    _participant2 = snapshotData['participant2'] as String?;
    _participant3 = snapshotData['participant3'] as String?;
    _participant4 = snapshotData['participant4'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('matches');

  static Stream<MatchesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => MatchesRecord.fromSnapshot(s));

  static Future<MatchesRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => MatchesRecord.fromSnapshot(s));

  static MatchesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      MatchesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static MatchesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      MatchesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'MatchesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is MatchesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createMatchesRecordData({
  String? courtName,
  String? courtDate,
  String? courtTime,
  String? userId,
  int? participantsJoined,
  int? maxParticipants,
  String? participants,
  String? participant1,
  String? participant2,
  String? participant3,
  String? participant4,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'courtName': courtName,
      'courtDate': courtDate,
      'courtTime': courtTime,
      'userId': userId,
      'participantsJoined': participantsJoined,
      'maxParticipants': maxParticipants,
      'participants': participants,
      'participant1': participant1,
      'participant2': participant2,
      'participant3': participant3,
      'participant4': participant4,
    }.withoutNulls,
  );

  return firestoreData;
}

class MatchesRecordDocumentEquality implements Equality<MatchesRecord> {
  const MatchesRecordDocumentEquality();

  @override
  bool equals(MatchesRecord? e1, MatchesRecord? e2) {
    return e1?.courtName == e2?.courtName &&
        e1?.courtDate == e2?.courtDate &&
        e1?.courtTime == e2?.courtTime &&
        e1?.userId == e2?.userId &&
        e1?.participantsJoined == e2?.participantsJoined &&
        e1?.maxParticipants == e2?.maxParticipants &&
        e1?.participants == e2?.participants &&
        e1?.participant1 == e2?.participant1 &&
        e1?.participant2 == e2?.participant2 &&
        e1?.participant3 == e2?.participant3 &&
        e1?.participant4 == e2?.participant4;
  }

  @override
  int hash(MatchesRecord? e) => const ListEquality().hash([
        e?.courtName,
        e?.courtDate,
        e?.courtTime,
        e?.userId,
        e?.participantsJoined,
        e?.maxParticipants,
        e?.participants,
        e?.participant1,
        e?.participant2,
        e?.participant3,
        e?.participant4
      ]);

  @override
  bool isValidKey(Object? o) => o is MatchesRecord;
}
