import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'join_match_model.dart';
export 'join_match_model.dart';

class JoinMatchWidget extends StatefulWidget {
  const JoinMatchWidget({
    super.key,
    String? courtname,
    this.courtnameconf,
    int? maxParticipant,
  })  : this.courtname = courtname ?? 'the court name',
        this.maxParticipant = maxParticipant ?? 4;

  final String courtname;
  final String? courtnameconf;
  final int maxParticipant;

  @override
  State<JoinMatchWidget> createState() => _JoinMatchWidgetState();
}

class _JoinMatchWidgetState extends State<JoinMatchWidget> {
  late JoinMatchModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => JoinMatchModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => _model.unfocusNode.canRequestFocus
          ? FocusScope.of(context).requestFocus(_model.unfocusNode)
          : FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: Color(0xFFF1F4F8),
        body: SafeArea(
          top: true,
          child: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(16.0, 16.0, 16.0, 16.0),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                Text(
                  'Choose a match to join.',
                  style: FlutterFlowTheme.of(context).headlineMedium.override(
                        fontFamily: 'Inter',
                        color: Color(0xFF14181B),
                        fontSize: 22.0,
                        letterSpacing: 0.0,
                        fontWeight: FontWeight.w500,
                      ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 16.0),
                  child: Text(
                    'These are matches that are started by other users.\nFeel free to join a match and have fun don\'t forget to\nhave fun!',
                    textAlign: TextAlign.center,
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Readex Pro',
                          letterSpacing: 0.0,
                        ),
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 1.0),
                  child: Container(
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: Colors.white,
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 1.0),
                  child: Container(
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: Colors.white,
                    ),
                  ),
                ),
                Flexible(
                  flex: 5,
                  child: StreamBuilder<List<MatchesRecord>>(
                    stream: queryMatchesRecord(
                      queryBuilder: (matchesRecord) => matchesRecord.where(
                        'userId',
                        isNotEqualTo: currentUserUid,
                      ),
                    ),
                    builder: (context, snapshot) {
                      // Customize what your widget looks like when it's loading.
                      if (!snapshot.hasData) {
                        return Center(
                          child: SizedBox(
                            width: 50.0,
                            height: 50.0,
                            child: CircularProgressIndicator(
                              valueColor: AlwaysStoppedAnimation<Color>(
                                FlutterFlowTheme.of(context).primary,
                              ),
                            ),
                          ),
                        );
                      }
                      List<MatchesRecord> listViewMatchesRecordList =
                          snapshot.data!;
                      return ListView.builder(
                        padding: EdgeInsets.zero,
                        shrinkWrap: true,
                        scrollDirection: Axis.vertical,
                        itemCount: listViewMatchesRecordList.length,
                        itemBuilder: (context, listViewIndex) {
                          final listViewMatchesRecord =
                              listViewMatchesRecordList[listViewIndex];
                          return Visibility(
                            visible: (listViewMatchesRecord.participantsJoined <
                                    4) &&
                                !((listViewMatchesRecord.participant1 ==
                                        currentUserEmail) ||
                                    (listViewMatchesRecord.participant2 ==
                                        currentUserEmail) ||
                                    (listViewMatchesRecord.participant3 ==
                                        currentUserEmail) ||
                                    (listViewMatchesRecord.participant4 ==
                                        currentUserEmail)),
                            child: InkWell(
                              splashColor: Colors.transparent,
                              focusColor: Colors.transparent,
                              hoverColor: Colors.transparent,
                              highlightColor: Colors.transparent,
                              onTap: () async {
                                var confirmDialogResponse =
                                    await showDialog<bool>(
                                          context: context,
                                          builder: (alertDialogContext) {
                                            return AlertDialog(
                                              title: Text('Confirmation '),
                                              content: Text(
                                                  'Press \'confirm\' to join. Otherwise press \'cancel\' to go back.'),
                                              actions: [
                                                TextButton(
                                                  onPressed: () =>
                                                      Navigator.pop(
                                                          alertDialogContext,
                                                          false),
                                                  child: Text('Cancel'),
                                                ),
                                                TextButton(
                                                  onPressed: () =>
                                                      Navigator.pop(
                                                          alertDialogContext,
                                                          true),
                                                  child: Text('Confirm'),
                                                ),
                                              ],
                                            );
                                          },
                                        ) ??
                                        false;
                                if (confirmDialogResponse) {
                                  await listViewMatchesRecord.reference.update({
                                    ...createMatchesRecordData(
                                      participants:
                                          '${listViewMatchesRecord.participants}${currentUserEmail}',
                                      maxParticipants:
                                          listViewMatchesRecord.maxParticipants,
                                    ),
                                    ...mapToFirestore(
                                      {
                                        'participantsJoined':
                                            FieldValue.increment(1),
                                      },
                                    ),
                                  });
                                  if (listViewMatchesRecord.participant2 ==
                                          null ||
                                      listViewMatchesRecord.participant2 ==
                                          '') {
                                    await listViewMatchesRecord.reference
                                        .update(createMatchesRecordData(
                                      participant2: currentUserEmail,
                                    ));
                                  } else {
                                    if (listViewMatchesRecord.participant3 ==
                                            null ||
                                        listViewMatchesRecord.participant3 ==
                                            '') {
                                      await listViewMatchesRecord.reference
                                          .update(createMatchesRecordData(
                                        participant3: currentUserEmail,
                                      ));
                                    } else {
                                      await listViewMatchesRecord.reference
                                          .update(createMatchesRecordData(
                                        participant4: currentUserEmail,
                                      ));
                                    }
                                  }
                                } else {
                                  Navigator.pop(context);
                                }
                              },
                              child: ListTile(
                                title: Text(
                                  listViewMatchesRecord.courtName,
                                  style: FlutterFlowTheme.of(context)
                                      .bodyLarge
                                      .override(
                                        fontFamily: 'Readex Pro',
                                        letterSpacing: 0.0,
                                      ),
                                ),
                                subtitle: Text(
                                  '${listViewMatchesRecord.courtDate}               ${listViewMatchesRecord.courtTime}',
                                  style: FlutterFlowTheme.of(context)
                                      .labelMedium
                                      .override(
                                        fontFamily: 'Readex Pro',
                                        letterSpacing: 0.0,
                                      ),
                                ),
                                trailing: Icon(
                                  Icons.arrow_forward_ios,
                                  color: FlutterFlowTheme.of(context)
                                      .secondaryText,
                                  size: 20.0,
                                ),
                                dense: false,
                              ),
                            ),
                          );
                        },
                      );
                    },
                  ),
                ),
                Expanded(
                  flex: 3,
                  child: Align(
                    alignment: AlignmentDirectional(0.0, 1.0),
                    child: FFButtonWidget(
                      onPressed: () async {
                        context.pushNamed('bookcourt');
                      },
                      text: 'Go back to homepage',
                      options: FFButtonOptions(
                        height: 40.0,
                        padding: EdgeInsetsDirectional.fromSTEB(
                            24.0, 0.0, 24.0, 0.0),
                        iconPadding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                        color: Color(0xFFD5EF39),
                        textStyle:
                            FlutterFlowTheme.of(context).titleSmall.override(
                                  fontFamily: 'Readex Pro',
                                  color: Colors.white,
                                  letterSpacing: 0.0,
                                ),
                        elevation: 3.0,
                        borderSide: BorderSide(
                          color: Colors.transparent,
                          width: 1.0,
                        ),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
