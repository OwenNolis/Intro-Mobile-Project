// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

Future<List<String>> showBookedCourt(String currentUserID) async {
  try {
    // Query Firestore to fetch reservations associated with the user's ID
    QuerySnapshot querySnapshot = await FirebaseFirestore.instance
        .collection('reservations')
        .where('userId', isEqualTo: currentUserID)
        .get();

    // Extract booked court details from query snapshot
    List<String> bookedCourts = [];
    querySnapshot.docs.forEach((doc) {
      String courtDetail =
          'Court Date: ${doc['courtDate']}, Court Time: ${doc['courtTime']}, Court Name: ${doc['courtName']}';
      bookedCourts.add(courtDetail);
    });

    return bookedCourts;
  } catch (e) {
    print('Error retrieving booked court details: $e');
    return []; // Return empty list if there's an error
  }
}
// Set your action name, define your arguments and return parameter,
// and then add the boilerplate code using the green button on the right!
