// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

Future<String> bookedCourtsNullOrNot(String currentUserID) async {
  try {
    // Query Firestore to check for reservations associated with the user's ID
    QuerySnapshot querySnapshot = await FirebaseFirestore.instance
        .collection('reservations')
        .where('userId', isEqualTo: currentUserID)
        .get();

    // Check if there are any reservations
    if (querySnapshot.docs.isNotEmpty) {
      // User has a booked court
      return 'User has a booked court.';
    } else {
      // User does not have a booked court
      return 'User does not have a booked court. Please book a court first.';
    }
  } catch (e) {
    print('Error checking booked court: $e');
    return 'An error occurred while checking booked court.';
  }
}

// Set your action name, define your arguments and return parameter,
// and then add the boilerplate code using the green button on the right!
