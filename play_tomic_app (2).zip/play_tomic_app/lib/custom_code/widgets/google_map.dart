// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '/custom_code/actions/index.dart'; // Imports custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

class GoogleMap extends StatefulWidget {
  const GoogleMap({
    super.key,
    this.width,
    this.height,
    this.courtLocations,
    this.id,
    this.streetname,
    this.streetNumber,
    this.zipCode,
    this.city,
    this.land,
    this.location,
    this.latitude,
    this.longitude,
  });

  final double? width;
  final double? height;
  final List<CourtLocationsRecord>? courtLocations;
  final List<String>? id;
  final List<String>? streetname;
  final List<String>? streetNumber;
  final List<String>? zipCode;
  final List<String>? city;
  final List<String>? land;
  final List<LatLng>? location;
  final List<double>? latitude;
  final List<double>? longitude;

  @override
  State<GoogleMap> createState() => _GoogleMapState();
}

class _GoogleMapState extends State<GoogleMap> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
