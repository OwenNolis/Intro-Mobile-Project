import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class CourtLocationsRecord extends FirestoreRecord {
  CourtLocationsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "courtName" field.
  String? _courtName;
  String get courtName => _courtName ?? '';
  bool hasCourtName() => _courtName != null;

  // "streetName" field.
  String? _streetName;
  String get streetName => _streetName ?? '';
  bool hasStreetName() => _streetName != null;

  // "streetNumber" field.
  String? _streetNumber;
  String get streetNumber => _streetNumber ?? '';
  bool hasStreetNumber() => _streetNumber != null;

  // "zipCode" field.
  String? _zipCode;
  String get zipCode => _zipCode ?? '';
  bool hasZipCode() => _zipCode != null;

  // "city" field.
  String? _city;
  String get city => _city ?? '';
  bool hasCity() => _city != null;

  // "land" field.
  String? _land;
  String get land => _land ?? '';
  bool hasLand() => _land != null;

  // "location" field.
  LatLng? _location;
  LatLng? get location => _location;
  bool hasLocation() => _location != null;

  // "latitude" field.
  double? _latitude;
  double get latitude => _latitude ?? 0.0;
  bool hasLatitude() => _latitude != null;

  // "longitude" field.
  double? _longitude;
  double get longitude => _longitude ?? 0.0;
  bool hasLongitude() => _longitude != null;

  void _initializeFields() {
    _courtName = snapshotData['courtName'] as String?;
    _streetName = snapshotData['streetName'] as String?;
    _streetNumber = snapshotData['streetNumber'] as String?;
    _zipCode = snapshotData['zipCode'] as String?;
    _city = snapshotData['city'] as String?;
    _land = snapshotData['land'] as String?;
    _location = snapshotData['location'] as LatLng?;
    _latitude = castToType<double>(snapshotData['latitude']);
    _longitude = castToType<double>(snapshotData['longitude']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('courtLocations');

  static Stream<CourtLocationsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => CourtLocationsRecord.fromSnapshot(s));

  static Future<CourtLocationsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => CourtLocationsRecord.fromSnapshot(s));

  static CourtLocationsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      CourtLocationsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static CourtLocationsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      CourtLocationsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'CourtLocationsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is CourtLocationsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createCourtLocationsRecordData({
  String? courtName,
  String? streetName,
  String? streetNumber,
  String? zipCode,
  String? city,
  String? land,
  LatLng? location,
  double? latitude,
  double? longitude,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'courtName': courtName,
      'streetName': streetName,
      'streetNumber': streetNumber,
      'zipCode': zipCode,
      'city': city,
      'land': land,
      'location': location,
      'latitude': latitude,
      'longitude': longitude,
    }.withoutNulls,
  );

  return firestoreData;
}

class CourtLocationsRecordDocumentEquality
    implements Equality<CourtLocationsRecord> {
  const CourtLocationsRecordDocumentEquality();

  @override
  bool equals(CourtLocationsRecord? e1, CourtLocationsRecord? e2) {
    return e1?.courtName == e2?.courtName &&
        e1?.streetName == e2?.streetName &&
        e1?.streetNumber == e2?.streetNumber &&
        e1?.zipCode == e2?.zipCode &&
        e1?.city == e2?.city &&
        e1?.land == e2?.land &&
        e1?.location == e2?.location &&
        e1?.latitude == e2?.latitude &&
        e1?.longitude == e2?.longitude;
  }

  @override
  int hash(CourtLocationsRecord? e) => const ListEquality().hash([
        e?.courtName,
        e?.streetName,
        e?.streetNumber,
        e?.zipCode,
        e?.city,
        e?.land,
        e?.location,
        e?.latitude,
        e?.longitude
      ]);

  @override
  bool isValidKey(Object? o) => o is CourtLocationsRecord;
}
